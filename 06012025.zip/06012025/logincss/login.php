<?php
$servername = "sql211.infinityfree.com";
$username = "if0_36126139"; // Replace with your database username
$password = "RKrishna9398"; // Replace with your database password
$dbname = "if0_36126139_ATETDB"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form inputs
$user = $_POST['username'];
$pass = $_POST['password'];

// Prepare and execute SQL query
$sql = $conn->prepare("SELECT * FROM ATET_Login_Creds WHERE Username = ? AND Password = ?");
$sql->bind_param("ss", $user, $pass);
$sql->execute();
$result = $sql->get_result();

if ($result->num_rows > 0) {
    //echo "Login successful!";
    header("Location: atethomepage.html");
    exit();
} else {
    echo "Invalid username or password.";
}

$sql->close();
$conn->close();
?>
