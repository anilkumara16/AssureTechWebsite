<?php
$conn = new mysqli("sql211.infinityfree.com", "if0_36126139", "RKrishna9398", "if0_36126139_ATETDB");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    echo "Connected Failed!";
}
echo "Connected successfully!";
?>
