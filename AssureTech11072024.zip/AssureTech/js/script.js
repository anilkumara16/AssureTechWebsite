function sendMail(){
	
	//let parms = {
	//	name : document.getElementById("name").value,
    //	email : document.getElementById("email").value,
	//	phno : document.getElementById("phno").value,
	//	msg : document.getElementById("msg").value,
	//}
	alert('sending mail..!!');
	emailjs.send("service_hvely4m","template_p4ibxmv",{
        name: document.getElementById("name").value,
        phno: document.getElementById("phno").value,
        email: document.getElementById("email").value,
        msg: document.getElementById("msg").value,
    }).then(
	(response) => {
        alert('mail sent!!');
		console.log('SUCCESS!', response.status, response.text);
		//window.location.reload();
		//alert(response.text)
	},
	(error) => {
        alert(error);
		console.log('FAILED...', error);
		//alert(response.text)
	},
	);
}