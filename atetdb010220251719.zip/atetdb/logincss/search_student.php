<?php
// Database connection
$host = "sql211.infinityfree.com"; // Replace with your database host
$username = "if0_36126139"; // Replace with your database username
$password = "RKrishna9398"; // Replace with your database password
$dbname = "if0_36126139_ATETDB"; // Replace with your database name

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch student ID from the GET request
if (isset($_GET['studentId']) && !empty($_GET['studentId'])) {
    $studentId = intval($_GET['studentId']); // Sanitize input to prevent SQL injection

    // Query to fetch student details
    $sql = "SELECT * FROM Students_202425 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $studentId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch the student's details
        $student = $result->fetch_assoc();
        /*echo json_encode([
            "status" => "success",
            "data" => $student,
        ]);*/
        $queryString = http_build_query($student);
        header("Location: viewStudent.html?$queryString");
        exit;
    } else {
        // No student found
        /*echo json_encode([
            "status" => "error",
            "message" => "Student not found.",
        ]);*/
        $msg = "Student not found";
        header("Location: viewStudent.html?$msg");
        exit;
    }

    $stmt->close();
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid Student ID.",
    ]);
}

// Close connection
$conn->close();
?>
