<?php
// Database connection settings
$host = "sql211.infinityfree.com"; // Change this to your database host
$username = "if0_36126139";  // Change this to your database username
$password = "RKrishna9398";      // Change this to your database password
$dbname = "if0_36126139_ATETDB"; // Change this to your database name

// Create a connection to the database
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the form data
$studentId = $_POST['studentId'];
$totalMarks = $_POST['totalMarks'] * 2; // This should always be 50
$qAndAMarks = $_POST['qAndAMarks'] * 2; // Multiply by 2
$oralMarks = $_POST['oralMarks'] * 2;   // Multiply by 2
$labPracticalMarks = $_POST['labPracticalMarks'] * 2; // Multiply by 2
$attendanceMarks = $_POST['attenanceMarks'] * 2; // Multiply by 2

// Sanitize input to prevent SQL injection
$studentId = $conn->real_escape_string($studentId);
$qAndAMarks = $conn->real_escape_string($qAndAMarks);
$oralMarks = $conn->real_escape_string($oralMarks);
$labPracticalMarks = $conn->real_escape_string($labPracticalMarks);
$attendanceMarks = $conn->real_escape_string($attendanceMarks);

// Check if the student's marks already exist in the database
$sql_check = "SELECT * FROM result_202425 WHERE student_id = '$studentId'";
$result_check = $conn->query($sql_check);

if ($result_check->num_rows > 0) {
    // If result already exists, alert and stop further processing
    echo "<script>alert('The result has already been updated for this student!'); window.location.href='addResult.html';</script>";
    exit();
}

// Calculate the total obtained marks
$totalObtainedMarks = $qAndAMarks + $oralMarks + $labPracticalMarks + $attendanceMarks;

// Prepare the SQL query to insert the marks data into the database
$sql_insert = "INSERT INTO result_202425 (student_id, total_marks, q_and_a_marks, oral_marks, lab_practical_marks, attendance_marks, total_obtained_marks)
               VALUES ('$studentId', '$totalMarks', '$qAndAMarks', '$oralMarks', '$labPracticalMarks', '$attendanceMarks', '$totalObtainedMarks')";

// Execute the query
if ($conn->query($sql_insert) === TRUE) {
    echo "<script>alert('Marks details successfully inserted!'); window.location.href='addResult.html';</script>";
} else {
    echo "Error: " . $sql_insert . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>
