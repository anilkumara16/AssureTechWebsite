<?php
$servername = "sql211.infinityfree.com"; // Change if necessary
$username = "if0_36126139"; // Change according to your database credentials
$password = "RKrishna9398"; // Change if necessary
$database = "if0_36126139_ATETDB"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if request is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate POST variables
    if (isset($_POST['studentId'], $_POST['receiptNo'], $_POST['amount'], $_POST['date'])) {
        $studentId = $_POST['studentId'];
        $receiptNo = $_POST['receiptNo'];
        $amount = $_POST['amount'];
        $date = $_POST['date'];

        // First, check if the receipt_no already exists in the database
        $checkSql = "SELECT * FROM receipt_202425 WHERE receipt_no = ?";
        $checkStmt = $conn->prepare($checkSql);
        $checkStmt->bind_param("s", $receiptNo);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows > 0) {
            // Receipt number already exists, return an error
            echo "<script>
                alert('Error: Receipt number already exists');
                window.location.href = 'addRct.html';
                </script>";
        } else {
            // Prepare SQL statement to insert data
            $sql = "INSERT INTO receipt_202425 (student_id, receipt_no, amount, payment_date) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);

            if ($stmt) {
                $stmt->bind_param("isds", $studentId, $receiptNo, $amount, $date);

                if ($stmt->execute()) {
                    // Success message
                    echo "<script>
                        alert('Receipt details inserted successfully.');
                        window.location.href = 'addRct.html';
                        </script>";
                } else {
                    // Failure message for execution error
                    echo "<script>
                        alert('Error: " . $stmt->error . "');
                        window.location.href = 'addRct.html';
                        </script>";
                }

                $stmt->close();
            } else {
                // Failure message for statement preparation failure
                echo "<script>
                    alert('Error: " . $conn->error . "');
                    window.location.href = 'addRct.html';
                    </script>";
            }
        }
        // Close the check statement
        $checkStmt->close();
    } else {
        // Error message for missing POST parameters
        echo "<script>
            alert('Error: Missing POST parameters');
            window.location.href = 'addRct.html';
            </script>";
    }
}

$conn->close();
?>
