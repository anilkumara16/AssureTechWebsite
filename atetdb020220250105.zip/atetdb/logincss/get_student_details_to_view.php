<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set Content Type to JSON
header('Content-Type: application/json');

// Database connection credentials
$host = 'sql211.infinityfree.com';  
$db = 'if0_36126139_ATETDB';  
$user = 'if0_36126139';  
$pass = 'RKrishna9398';  

// Create a connection to the database
$mysqli = new mysqli($host, $user, $pass, $db);

// Check if the connection is successful
if ($mysqli->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

// Check if studentId is provided
if (!isset($_GET['studentId']) || empty($_GET['studentId'])) {
    echo json_encode(['success' => false, 'message' => 'Student ID is required']);
    exit;
}

$studentId = $_GET['studentId'];

// Fetch student details
$query = "SELECT * FROM Students_202425 WHERE id = ?";
if ($stmt = $mysqli->prepare($query)) {
    $stmt->bind_param("i", $studentId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();

        // Fetch all receipt details for the student
        $receipts = [];
        $feeQuery = "SELECT receipt_no, amount, payment_date FROM receipt_202425 WHERE student_id = ?";
        if ($feeStmt = $mysqli->prepare($feeQuery)) {
            $feeStmt->bind_param("i", $studentId);
            $feeStmt->execute();
            $feeResult = $feeStmt->get_result();

            while ($row = $feeResult->fetch_assoc()) {
                $receipts[] = $row;
            }
            $feeStmt->close();
        }

        // Return JSON response
        echo json_encode([
            'success' => true,
            'student_name' => $student['student_name'],
            'parent_name' => $student['parent_name'],
            'contact_number' => $student['contact_number'],
            'school_name' => $student['school_name'],
            'standard' => $student['standard'],
            'batch_time' => $student['batch_time'],
            'total_fee' => "Not available",
            'receipts' => $receipts  // Send all receipts in the response
        ]);
    } else {
        // Student not found
        echo json_encode(['success' => false, 'message' => 'No student found with this ID']);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Error fetching student details']);
}

// Close the database connection
$mysqli->close();
?>
