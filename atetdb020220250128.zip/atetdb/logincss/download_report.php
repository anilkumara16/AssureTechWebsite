<?php
// Database connection
$servername = "sql211.infinityfree.com";
$username = "if0_36126139";
$password = "RKrishna9398";
$dbname = "if0_36126139_ATETDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $report_type = $_POST['ReportType'];

    // Function to export data to CSV
    function exportToCSV($filename, $result)
    {
        if ($result->num_rows > 0) {
            // Set headers for download
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=' . $filename . '.csv');

            // Open file stream
            $output = fopen('php://output', 'w');

            // Fetch and write column headers
            $columns = $result->fetch_fields();
            $header = [];
            foreach ($columns as $column) {
                $header[] = $column->name;
            }
            fputcsv($output, $header);

            // Fetch and write rows
            while ($row = $result->fetch_assoc()) {
                fputcsv($output, $row);
            }

            fclose($output);
            exit();
        } else {
            echo "No records found.";
        }
    }

    // Generate report based on selected type
    if ($report_type === "Complete Receipt Details") {
        $sql = "SELECT * FROM receipt_202425";
        $result = $conn->query($sql);
        exportToCSV("Receipt_Details", $result);
    } 
    elseif ($report_type === "Complete Student DB Details") {
        $sql = "SELECT * FROM Students_202425";
        $result = $conn->query($sql);
        exportToCSV("Student_DB_Details", $result);
    } 
    elseif ($report_type === "Complete Paid Student List") {
        $sql = "
            SELECT s.*, SUM(r.amount) AS total_paid 
            FROM Students_202425 s
            LEFT JOIN receipt_202425 r ON s.id = r.student_id
            GROUP BY s.id
            HAVING total_paid >= s.total_fee";
        $result = $conn->query($sql);
        exportToCSV("Paid_Student_List", $result);
    } 
    elseif ($report_type === "Pending Fee Student List") {
        $sql = "
            SELECT s.*, 
                   SUM(r.amount) AS total_paid, 
                   s.total_fee - COALESCE(SUM(r.amount), 0) AS balance_fee
            FROM Students_202425 s
            LEFT JOIN receipt_202425 r ON s.id = r.student_id
            GROUP BY s.id
            HAVING balance_fee > 0";
        $result = $conn->query($sql);
        exportToCSV("Pending_Fee_Student_List", $result);
    }
}

$conn->close();
?>
