<?php
// Database connection settings
$host = 'sql211.infinityfree.com'; // replace with your database host
$dbname = 'if0_36126139_ATETDB'; // replace with your database name
$username = 'if0_36126139'; // replace with your database username
$password = 'RKrishna9398'; // replace with your database password

// Establishing the connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit;
}

// Check if 'studentId' is set in the query string
if (isset($_GET['studentId'])) {
    $studentId = $_GET['studentId'];

    // Prepare the query to fetch student details based on the student ID
    $stmt = $pdo->prepare("SELECT student_name, parent_name, contact_number, school_name, standard, batch_time FROM Students_202425 WHERE id = :studentId");
    $stmt->bindParam(':studentId', $studentId, PDO::PARAM_INT);

    try {
        $stmt->execute();
        
        // Fetch the student data
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Check if student was found
        if ($student) {
                    echo json_encode([
                    'success' => true,
                    'student_name' => isset($student['student_name']) ? $student['student_name'] : 'N/A',
                    'parent_name' => isset($student['parent_name']) ? $student['parent_name'] : 'N/A',
                    'contact_number' => isset($student['contact_number']) ? $student['contact_number'] : 'N/A',
                    'school_name' => isset($student['school_name']) ? $student['school_name'] : 'N/A',
                    'standard' => isset($student['standard']) ? $student['standard'] : 'N/A',
                    'batch_time' => isset($student['batch_time']) ? $student['batch_time'] : 'N/A'
        ]);
        } else {
            echo json_encode(['success' => false]);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Student ID not provided']);
}
?>
