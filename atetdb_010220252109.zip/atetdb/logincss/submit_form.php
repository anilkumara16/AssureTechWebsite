<?php
// Database connection details
$servername = "sql211.infinityfree.com";
$username = "if0_36126139";
$password = "RKrishna9398"; // Replace with your database password
$dbname = "if0_36126139_ATETDB"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $studentName = $conn->real_escape_string($_POST['studentName']);
    $parentName = $conn->real_escape_string($_POST['parentName']);
    $contactDetails = $conn->real_escape_string($_POST['contactDetails']);
    $schoolName = $conn->real_escape_string($_POST['schoolName']);
    $standard = $conn->real_escape_string($_POST['standard']);
    $batchTime = $conn->real_escape_string($_POST['batchTime']);

    // SQL query to insert data into the students table
    $sql = "INSERT INTO Students_202425 (student_name, parent_name, contact_number, school_name, standard, batch_time) 
            VALUES ('$studentName', '$parentName', '$contactDetails', '$schoolName', '$standard', '$batchTime')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        $last_id = $conn->insert_id;

        // Display success message with the ID
        echo "<script>
                alert('New record created successfully. Student ID: $last_id');
                window.location.href = 'addStudent.html';
              </script>";
    } else {
        echo "<script>
                alert('Error: " . $conn->error . "');
                window.location.href = 'addStudent.html';
              </script>";
    }
}

// Close the connection
$conn->close();
?>
