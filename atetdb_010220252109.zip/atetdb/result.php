<?php
// Database connection
$servername = "sql211.infinityfree.com";
$username = "if0_36126139";
$password = "RKrishna9398";
$dbname = "if0_36126139_ATETDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Variables to store student details and results
$student_name = '';
$parent_name = '';
$results = null;

// If form is submitted, fetch the data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student_id'];

    // Fetch student details
    $sql_student = "SELECT * FROM Students_202425 WHERE id = ?";
    $stmt = $conn->prepare($sql_student);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $student_result = $stmt->get_result();

    if ($student_result->num_rows > 0) {
        $student_row = $student_result->fetch_assoc();
        $student_name = $student_row['student_name'];
        $parent_name = $student_row['parent_name'];

        // Fetch results for the student
        $sql_results = "SELECT * FROM result_202425 WHERE student_id = ?";
        $stmt_results = $conn->prepare($sql_results);
        $stmt_results->bind_param("i", $student_id);
        $stmt_results->execute();
        $results = $stmt_results->get_result()->fetch_assoc();
    } else {
        $error_message = "Student not found.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 1rem;
            font-size: 24px;
            font-weight: bold;
        }
        .form-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            background: #ffffff;
            padding: 20px;
            width: 50%;
            margin: 20px auto;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        .form-inline {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        .form-inline label {
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }
        .form-inline input {
            width: 220px;
            padding: 10px;
            font-size: 16px;
            border: 2px solid #ccc;
            border-radius: 5px;
            outline: none;
            text-align: center;
        }
        .form-inline input:focus {
            border-color: #4CAF50;
            box-shadow: 0px 0px 8px rgba(76, 175, 80, 0.5);
        }
        .form-inline button {
            padding: 10px 15px;
            font-size: 16px;
            color: white;
            background-color: #4CAF50;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        .form-inline button:hover {
            background-color: #45a049;
            transform: scale(1.05);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 18px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #000;
        }
        th {
            background-color: #e0e0e0;
            text-align: center;
        }
        .bold {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <h2>Assure Tech Education Trust</h2>
    </header>

    <div class="form-container">
        <form method="POST" action="">
            <div class="form-inline">
                <label for="student_id">Enter Student ID:</label>
                <input type="number" id="student_id" name="student_id" required placeholder="Enter ID...">
                <button type="submit">Get Results</button>
            </div>
        </form>

        <?php if (!empty($student_name)): ?>
            <table>
                <tr>
                    <td class="bold">Name:</td>
                    <td><?= $student_name ?></td>
                </tr>
                <tr>
                    <td class="bold">Parent's Name:</td>
                    <td><?= $parent_name ?></td>
                </tr>
            </table>

            <table>
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Marks Obtained</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Q&A Marks</td>
                        <td style="text-align: center;"><?= $results['q_and_a_marks'] ?></td>
                    </tr>
                    <tr>
                        <td>Oral Marks</td>
                        <td style="text-align: center;"><?= $results['oral_marks'] ?></td>
                    </tr>
                    <tr>
                        <td>Lab Practical Marks</td>
                        <td style="text-align: center;"><?= $results['lab_practical_marks'] ?></td>
                    </tr>
                    <tr>
                        <td>Attendance Marks</td>
                        <td style="text-align: center;"><?= $results['attendance_marks'] ?></td>
                    </tr>
                    <tr>
                        <td class="bold">Marks Obtained</td>
                        <td class="bold" style="text-align: center;"><?= $results['total_obtained_marks'] ?></td>
                    </tr>
                    <tr>
                        <td class="bold">Max Marks</td>
                        <td class="bold" style="text-align: center;"><?= $results['total_marks'] ?></td>
                    </tr>
                    <tr>
                        <td class="bold">Percentage (%)</td>
                        <td class="bold" style="text-align: center;">
                            <?php 
                                if (!empty($results['total_marks']) && $results['total_marks'] > 0) {
                                    echo number_format(($results['total_obtained_marks'] / $results['total_marks']) * 100, 2) . "%";
                                } else {
                                    echo "N/A"; // Display N/A if total_marks is 0 or missing
                                }
                            ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        <?php elseif (isset($error_message)): ?>
            <p><?= $error_message ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
